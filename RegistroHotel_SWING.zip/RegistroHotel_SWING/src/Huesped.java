import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Huesped {
    private JPanel panel;
    private JPanel panelPrincipal;
    private JTextField NombreText;
    private JTextField EdadText;
    private JTextField CedulaText;
    private JTextField TipoText;
    private JTextField numHabitacionesText;
    private JButton ingresarbt;
    private JButton mostrarRegistrosButton;
    private JList list1;
    private StringBuilder registros; // Almacena los registros
    private JTextArea registroArea; // Área de texto para mostrar registros


    private int habitacionesSuitDisponibles = 2; // Habitaciones disponibles para suit
    public static final double  PRECIOSENCILLA = 40 ;
    public static final double PRECIOSUIT = 80 ;
    public static final double PRECIODOBLE = 60 ;

   //Calcular el precio de la habitacion
    private Double calcularPrecioHabitacion(String tipoHabitacion, int numHabitaciones) {
        if (tipoHabitacion == null || tipoHabitacion.isEmpty()) {
            return null; // Retorna null si el tipo de habitación es inválido
        }

        switch (tipoHabitacion.toLowerCase()) {
            case "sencilla":
                return PRECIOSENCILLA * numHabitaciones;
            case "doble":
                return PRECIODOBLE * numHabitaciones;
            case "suit":
                return PRECIOSUIT * numHabitaciones;
            default:
                return null; // Retorna null si el tipo de habitación es desconocido
        }
    }

    public Huesped() {

        //Se crea el fram principal
        JFrame frame = new JFrame("Registro Habitacion");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);

        panelPrincipal = new JPanel(new BorderLayout(10, 50));

        // Panel izquierdo
        JPanel panelIzquierdo = new JPanel();
        panelIzquierdo.setLayout(new BoxLayout(panelIzquierdo, BoxLayout.Y_AXIS));
        panelIzquierdo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        //Titulo y fuente
        JLabel tituloLabel = new JLabel("Formulario Huesped");
        tituloLabel.setFont(new Font("Berlin Sans FB Demi", Font.BOLD, 28));
        tituloLabel.setHorizontalAlignment(SwingConstants.CENTER);

        //Paneles lado izquierdo
        panelIzquierdo.add(tituloLabel);
        panelIzquierdo.add(Box.createVerticalStrut(20));
        panelIzquierdo.add(new JLabel("Las habitaciones disponibles son:"));
        panelIzquierdo.add(new JLabel("   - Sencilla = $40 c/u"));
        panelIzquierdo.add(new JLabel("   - Doble = $60 c/u"));
        panelIzquierdo.add(new JLabel("   - Suit (Solo disponibles 2 Habitaciones) = $80 c/u"));

        // Panel derecho
        JPanel panelDerecho = new JPanel(new GridLayout(5, 2, 10, 50));
        panelDerecho.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));

        panelDerecho.add(new JLabel("Nombre:"));
        NombreText = new JTextField(10); //numero de columnas visibles
        panelDerecho.add(NombreText); // Se coloca el cuadro de texto en el panel derecho

        panelDerecho.add(new JLabel("Cédula:"));
        CedulaText = new JTextField(10);
        panelDerecho.add(CedulaText);

        panelDerecho.add(new JLabel("Edad (En números):"));
        EdadText = new JTextField(10);
        panelDerecho.add(EdadText);

        panelDerecho.add(new JLabel("Tipo de Habitación (En minúsculas):"));
        TipoText = new JTextField(10);
        panelDerecho.add(TipoText);

        panelDerecho.add(new JLabel("Número de Habitaciones (Solo número):"));
        numHabitacionesText = new JTextField(10);
        panelDerecho.add(numHabitacionesText);

        // Panel inferior
        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        ingresarbt = new JButton("Ingresar");
        mostrarRegistrosButton = new JButton("Mostrar Registros");
        panelInferior.add(ingresarbt);
        panelInferior.add(mostrarRegistrosButton);

        // Área de registros
        registros = new StringBuilder(); //Se crea el objeto StringBuilder
        registroArea = new JTextArea(10, 15); //Se crea un area de texto donde se muestra el texto en varias lineas, el 10 de las lineas visibles y el 15 de las columnas
        registroArea.setEditable(false); //El false para que el area de texto no se pueda editar
        JScrollPane scrollPane = new JScrollPane(registroArea);
        panelPrincipal.add(scrollPane, BorderLayout.EAST);

        // Agregar paneles al principal
        panelPrincipal.add(panelIzquierdo, BorderLayout.WEST);
        panelPrincipal.add(panelDerecho, BorderLayout.CENTER);
        panelPrincipal.add(panelInferior, BorderLayout.SOUTH);

        //Que sea visible
        frame.add(panelPrincipal);
        configurarEventos();
        frame.setVisible(true);
    }

    private void configurarEventos() {
        ingresarbt.addActionListener(new ActionListener() { //este metodo conecta el boton con el apartado de action performed que responde al click
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = NombreText.getText().trim();
                String edadStr = EdadText.getText().trim();
                String cedula = CedulaText.getText().trim();
                String tipoHabitacion = TipoText.getText().trim().toLowerCase();
                String numHabitacionesStr = numHabitacionesText.getText().trim();

                if (nombre.isEmpty() || edadStr.isEmpty() || cedula.isEmpty() || tipoHabitacion.isEmpty() || numHabitacionesStr.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Debe llenar todos los datos para poder registrar", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                int edad, numHabitaciones;
                try {
                    edad = Integer.parseInt(edadStr);
                    numHabitaciones = Integer.parseInt(numHabitacionesStr);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Edad y número de habitaciones deben ser números válidos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    numHabitaciones = Integer.parseInt(numHabitacionesStr);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null,
                            "El número de habitaciones debe ser un número válido",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (edad < 18) {
                    JOptionPane.showMessageDialog(null, "Debe ser mayor de edad para registrarse una habitacion...",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }



                if (tipoHabitacion.equals("suit") && numHabitaciones > habitacionesSuitDisponibles) {
                    JOptionPane.showMessageDialog(null, "Solo queda " + habitacionesSuitDisponibles
                                    + " habitaciones 'suit' ",
                            "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }else {
                    habitacionesSuitDisponibles -= numHabitaciones;

                }


               //Se calcula precio final
                Double precioFinal = calcularPrecioHabitacion(tipoHabitacion, numHabitaciones);
                if (precioFinal == null) {
                    JOptionPane.showMessageDialog(null, "Tipo de habitación no válido", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    // Si el precio es válido, mostramos el precio final
                    JOptionPane.showMessageDialog(null, "El precio final es: " + precioFinal);
                }

                // Agregar los datos al registro
                registros.append("Nombre: \n").append(nombre)
                        .append(", \nEdad: \n").append(edad)
                        .append(", \nCédula: \n").append(cedula)
                        .append(", \nTipo: \n").append(tipoHabitacion)
                        .append(", \nHabitaciones: \n").append(numHabitaciones)
                        .append(", \nPrecio final:  \n$").append(precioFinal == null ? "N/A" : precioFinal)
                        .append("\n---------------------")
                        .append("\n");




                JOptionPane.showMessageDialog(null, "Registro exitoso", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        mostrarRegistrosButton.addActionListener(new ActionListener() { // Boton mostrar registro
            @Override
            public void actionPerformed(ActionEvent e) { //el metodo que define que asa cuando se da click
                registroArea.setText(registros.toString());
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Huesped::new); //Aqui se crea y se ejecuta en el ilo correcto del EDT
    }
}


