public class RegistroHabitacion {
    private String nombre;
    private String cedula;
    private int edad;
    private String tipo;
    private int numHabitaciones;
    public static final double PRECIOSENCILLA = 40;
    public static final double PRECIOSUIT = 80;
    public static final double PRECIODOBLE = 60;

    public RegistroHabitacion(String nombre, String cedula, int edad, String tipo, int numHabitaciones) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.edad = edad;
        this.tipo = tipo;
        this.numHabitaciones = numHabitaciones;
    }

    public RegistroHabitacion() {
        this.nombre = "";
        this.cedula = "";
        this.edad = 0;
        this.tipo = "";
        this.numHabitaciones = 0;
    }



    public String generarRegistro() {
        return cedula.substring(6);
    }

    public double calcularPago() {
        switch (tipo.toLowerCase()) {
            case "suit":
                return PRECIOSUIT * numHabitaciones;
            case "doble":
                return PRECIODOBLE * numHabitaciones;
            default:
                return PRECIOSENCILLA * numHabitaciones;
        }
    }

    @Override
    public String toString() {
        return "\nHuesped:\n" +
                "Nombre: " + nombre +
                "\nCedula: " + cedula +
                "\nEdad: " + edad +
                "\nTipo: " + tipo +
                "\nNúmero de Habitaciones: " + numHabitaciones;
    }
}
